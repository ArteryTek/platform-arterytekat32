/**
  **************************************************************************
  * @file     readme.txt 
  * @version  v2.1.1
  * @date     2022-07-22
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, systick used for 
  delay function. led2~4 fresh fast or slow exchanged by user button.
