# PlatformIO platform package for ArteryTek AT32 MCUs

### Installation:
1. Click "PlatformIO Core CLI" from VSCode PlatformIO Panel -> Quick Access -> Miscellaneous.
2. Enter below install commands:
``` 
pio pkg install -g -p https://dl.git.ltd/pio-at32-win-1.0.1.tar.gz
```